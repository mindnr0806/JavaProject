package com.kh.practice.chap01_poly.view;

import java.util.Scanner;

import com.kh.practice.chap01_poly.controller.LibraryController;

public class LibraryMenu {
	
	private LibraryController lc;
	private Scanner sc = new Scanner(System.in);
	
	
	
	public void mainMenu() {
		System.out.println("이름 : ");
		System.out.println("나이 : ");
		System.out.println("성별 : ");
		System.out.println("==== 메뉴 ====");
		System.out.println("1. 마이페이지");
		System.out.println("2. 도서 전체 조회");
		System.out.println("3. 도서 검색");
		System.out.println("4. 도서 대여하기");
		System.out.println("9. 프로그램 종료하기");
		return;
	}
	
	public void selectAll() {
		System.out.println("메뉴 번호 : ");
		for(int i=0; i<bList.length; i++) {
			if(bList[i]).getTitle().equals(title)) {
				no.nextint
			}
		}
	}
	
	
	public void searchBook() {
		System.out.println("bList[0] ");
		
		
	}
	
	
	public void  rentBook() {}

}
