package com.kh.practice.chap01_poly.controller;

import com.kh.practice.chap01_poly.model.vo.Book;
import com.kh.practice.chap01_poly.model.vo.Member;

public class LibraryController {

	private Member mem;
	private Book[] bList() {
		
		
		
	}
	
	public void insertMember(Member mem)
	public Member myInfo() {}
	public Book[] = selectAll();
	public Book[] searchBook(String keyword);
	public int rentBook(int index);
	
}
