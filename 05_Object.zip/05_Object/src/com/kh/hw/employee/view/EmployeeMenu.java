package com.kh.hw.employee.view;

public class EmployeeMenu {

}
