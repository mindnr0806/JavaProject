package com.kh.example.practice4.run;

import com.kh.example.practice4.model.vo.Student;

public class Run {

	public static void main(String[] args) {
		Student s1 = new Student();
			
			s1.information();
			
			Student s2 = new Student("아이유");
			s2.information();
		
			
	}

}
